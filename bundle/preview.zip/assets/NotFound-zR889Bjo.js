import{j as t}from"./react-BV4tOWJx.js";import{c as i,Q as r,i as s}from"./index-BtGFKcKB.js";import{u as n}from"./i18n-Bl_3dfe0.js";import"./mock-D-VvTxCg.js";import"./radix-CHcYen7D.js";import"./data-BPUTXwXV.js";import"./charts-HISpf68h.js";/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e={name:"compass",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}]]};e.node;const a=i(e);function h(){const{t:o}=n();return t.jsx("main",{id:"main",className:"min-h-dvh grid place-items-center",children:t.jsx(r,{titleAs:"h1",icon:t.jsx(a,{}),title:o("errors.pageNotFound"),action:t.jsx(s,{to:"/",children:o("errors.goHome")})})})}export{h as NotFound};
