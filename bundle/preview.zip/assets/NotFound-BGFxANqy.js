import{c as s,u as n,j as t,O as a,l as c}from"./index-BSfR7h4I.js";/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o={name:"compass",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}]]};o.node;const r=s(o);function m(){const{t:e}=n();return t.jsx("div",{className:"min-h-dvh grid place-items-center",children:t.jsx(a,{icon:t.jsx(r,{}),title:e("errors.pageNotFound"),action:t.jsx(c,{to:"/",children:e("errors.goHome")})})})}export{m as NotFound};
