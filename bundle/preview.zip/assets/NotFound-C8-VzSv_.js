import{j as o}from"./react-B4EzUA83.js";import{c as e,H as s,f as i}from"./index-DYfimmoH.js";import{u as n}from"./i18n-DUE0lsR9.js";import"./mock-D-VvTxCg.js";import"./radix-CrGFGek0.js";import"./data-nszAG4Yc.js";import"./charts-CtQxhvzO.js";/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r={name:"compass",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}]]};r.node;const a=e(r);function f(){const{t}=n();return o.jsx("div",{className:"min-h-dvh grid place-items-center",children:o.jsx(s,{icon:o.jsx(a,{}),title:t("errors.pageNotFound"),action:o.jsx(i,{to:"/",children:t("errors.goHome")})})})}export{f as NotFound};
