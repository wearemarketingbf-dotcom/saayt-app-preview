import{j as o}from"./react-BV4tOWJx.js";import{c as e,M as s,h as i}from"./index-BmUfxfdq.js";import{u as n}from"./i18n-Bl_3dfe0.js";import"./mock-D-VvTxCg.js";import"./radix-CHcYen7D.js";import"./data-Da1SLm_b.js";import"./charts-HISpf68h.js";/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r={name:"compass",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}]]};r.node;const a=e(r);function h(){const{t}=n();return o.jsx("div",{className:"min-h-dvh grid place-items-center",children:o.jsx(s,{icon:o.jsx(a,{}),title:t("errors.pageNotFound"),action:o.jsx(i,{to:"/",children:t("errors.goHome")})})})}export{h as NotFound};
