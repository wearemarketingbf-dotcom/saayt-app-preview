import{k as s,j as r,q as e}from"./react-CnAZZXXo.js";function a(){const{search:t}=s();return r.jsx(e,{to:`/app/reports${t}`,replace:!0})}export{a as Insights};
