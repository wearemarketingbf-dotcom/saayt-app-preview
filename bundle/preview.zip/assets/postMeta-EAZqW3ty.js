import{c as e,z as n}from"./index-10B-6KiO.js";import{C as i}from"./calendar-days-oWiGozLP.js";import{T as t}from"./tag-CJtxCr27.js";/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a={name:"newspaper",size:24,node:[["path",{d:"M15 18h-5",key:"95g1m2"}],["path",{d:"M18 14h-8",key:"sponae"}],["path",{d:"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2",key:"39pd36"}],["rect",{width:"8",height:"4",x:"10",y:"6",rx:"1",key:"aywv1n"}]]};a.node;const r=e(a),c={draft:"neutral",pending_approval:"accent",scheduled:"info",publishing:"info",published:"ok",partially_published:"warn",failed:"crit",cancelled:"neutral"},d={STANDARD:r,OFFER:t,EVENT:i,ALERT:n},l={live:"ok",processing:"info",publishing:"info",pending:"neutral",skipped:"neutral",rejected:"crit",failed:"crit"};export{l as I,d as P,c as a};
